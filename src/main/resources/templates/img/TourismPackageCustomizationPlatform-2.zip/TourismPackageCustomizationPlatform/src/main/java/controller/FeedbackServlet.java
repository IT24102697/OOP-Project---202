package controller;

import dao.FeedbackDAO;
import model.Feedback;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/feedback")
public class FeedbackServlet extends HttpServlet {

    private FeedbackDAO feedbackDAO;

    @Override
    public void init() throws ServletException {
        feedbackDAO = new FeedbackDAO(); // create DAO instance
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deleteFeedback(request, response);
                break;
            default:
                listFeedbacks(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idStr = request.getParameter("id");
        String name = request.getParameter("name");
        String message = request.getParameter("message");

        if (idStr == null || idStr.isEmpty()) {
            // Create new
            int newId = feedbackDAO.getNextId();
            Feedback feedback = new Feedback(newId, name, message);
            feedbackDAO.addFeedback(feedback);
        } else {
            // Update existing
            int id = Integer.parseInt(idStr);
            Feedback updated = new Feedback(id, name, message);
            feedbackDAO.updateFeedback(updated);
        }

        response.sendRedirect("feedback");
    }

    private void listFeedbacks(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Feedback> feedbacks = feedbackDAO.getAllFeedbacks();
        request.setAttribute("feedbacks", feedbacks);
        RequestDispatcher dispatcher = request.getRequestDispatcher("feedback.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Feedback feedback = feedbackDAO.getFeedbackById(id);
        request.setAttribute("feedback", feedback);
        RequestDispatcher dispatcher = request.getRequestDispatcher("edit-feedback.jsp");
        dispatcher.forward(request, response);
    }

    private void deleteFeedback(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        feedbackDAO.deleteFeedback(id);
        response.sendRedirect("feedback");
    }
}
