package com.tourism.tourismplatform.controller;

import com.tourism.tourismplatform.model.TravelPackage;
import com.tourism.tourismplatform.service.TravelPackageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class WebController {

    @Autowired
    private TravelPackageService packageService;

    @GetMapping("/")
    public String home() {
        return "index"; // index.html homepage
    }

    @GetMapping("/packages")
    public String showPackages(Model model) {
        List<TravelPackage> packages = packageService.getAllPackagesSortedByCost();
        model.addAttribute("packages", packages);
        return "package-list";
    }

    @GetMapping("/explore")
    public String explore() {
        return "explore";
    }

    @GetMapping("/feedback")
    public String feedback() {
        return "feedback";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact-us";
    }
}
