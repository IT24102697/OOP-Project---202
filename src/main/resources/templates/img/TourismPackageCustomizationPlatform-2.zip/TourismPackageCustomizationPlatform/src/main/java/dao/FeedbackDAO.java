package dao;

import model.Feedback;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDAO {

    private static final String FILE_PATH = "feedback.txt"; // relative to project root

    // 🔁 Read all feedbacks
    public List<Feedback> getAllFeedbacks() {
        List<Feedback> feedbackList = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Feedback feedback = Feedback.fromString(line);
                feedbackList.add(feedback);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return feedbackList;
    }

    // ➕ Add new feedback
    public void addFeedback(Feedback feedback) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            writer.write(feedback.toString());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 🧽 Delete feedback by ID
    public void deleteFeedback(int id) {
        List<Feedback> feedbacks = getAllFeedbacks();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Feedback f : feedbacks) {
                if (f.getId() != id) {
                    writer.write(f.toString());
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ✏️ Update feedback by ID
    public void updateFeedback(Feedback updatedFeedback) {
        List<Feedback> feedbacks = getAllFeedbacks();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Feedback f : feedbacks) {
                if (f.getId() == updatedFeedback.getId()) {
                    writer.write(updatedFeedback.toString());
                } else {
                    writer.write(f.toString());
                }
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 🔍 Get feedback by ID (for editing)
    public Feedback getFeedbackById(int id) {
        for (Feedback f : getAllFeedbacks()) {
            if (f.getId() == id) return f;
        }
        return null;
    }

    // 🔢 Get next available ID
    public int getNextId() {
        int max = 0;
        for (Feedback f : getAllFeedbacks()) {
            if (f.getId() > max) max = f.getId();
        }
        return max + 1;
    }
}
