package com.tourism.tourismplatform.controller;

import com.tourism.tourismplatform.model.TravelPackage;
import com.tourism.tourismplatform.service.TravelPackageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/packages")
public class TravelPackageController {

    @Autowired
    private TravelPackageService travelPackageService;

    @GetMapping
    public List<TravelPackage> getAllPackages() {
        return travelPackageService.getAllPackagesSortedByCost();
    }

    @PostMapping
    public void addPackage(@RequestBody TravelPackage travelPackage) {
        travelPackageService.addPackage(travelPackage);
    }
}
