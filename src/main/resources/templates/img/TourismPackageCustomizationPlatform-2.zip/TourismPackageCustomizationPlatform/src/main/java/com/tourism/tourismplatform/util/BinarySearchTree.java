package com.tourism.tourismplatform.util;

import com.tourism.tourismplatform.model.TravelPackage;

import java.util.List;

public class BinarySearchTree {

    private Node root;

    public static class Node {
        TravelPackage data;
        Node left, right;

        public Node(TravelPackage data) {
            this.data = data;
        }
    }

    public void insert(TravelPackage data) {
        root = insertRec(root, data);
    }

    private Node insertRec(Node root, TravelPackage data) {
        if (root == null) return new Node(data);
        if (data.getCost() < root.data.getCost()) root.left = insertRec(root.left, data);
        else root.right = insertRec(root.right, data);
        return root;
    }

    public void inOrderTraversal(Node node, List<TravelPackage> list) {
        if (node != null) {
            inOrderTraversal(node.left, list);
            list.add(node.data);
            inOrderTraversal(node.right, list);
        }
    }

    public Node getRoot() {
        return root;
    }
}

