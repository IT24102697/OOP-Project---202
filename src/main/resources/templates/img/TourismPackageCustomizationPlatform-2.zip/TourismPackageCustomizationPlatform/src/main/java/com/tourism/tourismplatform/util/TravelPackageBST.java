package com.tourism.tourismplatform.util;

import com.tourism.tourismplatform.model.TravelPackage;

import java.util.ArrayList;
import java.util.List;

public class TravelPackageBST {

    private class Node {
        TravelPackage travelPackage;
        Node left, right;

        Node(TravelPackage travelPackage) {
            this.travelPackage = travelPackage;
        }
    }

    private Node root;

    public void insert(TravelPackage travelPackage) {
        root = insertRec(root, travelPackage);
    }

    private Node insertRec(Node root, TravelPackage travelPackage) {
        if (root == null) {
            return new Node(travelPackage);
        }

        if (travelPackage.getCost() < root.travelPackage.getCost()) {
            root.left = insertRec(root.left, travelPackage);
        } else {
            root.right = insertRec(root.right, travelPackage);
        }

        return root;
    }

    public List<TravelPackage> getAllPackagesSortedByCost() {
        List<TravelPackage> sortedList = new ArrayList<>();
        inOrderTraversal(root, sortedList);
        return sortedList;
    }

    private void inOrderTraversal(Node node, List<TravelPackage> list) {
        if (node != null) {
            inOrderTraversal(node.left, list);
            list.add(node.travelPackage);
            inOrderTraversal(node.right, list);
        }
    }

    public List<TravelPackage> getSortedPackagesByCost() {
        List<TravelPackage> sortedList = new ArrayList<>();
        inOrderTraversal(root, sortedList);
        return sortedList;
    }

}
