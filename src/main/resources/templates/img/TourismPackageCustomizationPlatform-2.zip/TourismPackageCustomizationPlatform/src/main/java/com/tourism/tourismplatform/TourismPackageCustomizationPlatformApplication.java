package com.tourism.tourismplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourismPackageCustomizationPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(TourismPackageCustomizationPlatformApplication.class, args);
    }
}
