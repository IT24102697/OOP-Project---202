package model;

public class Feedback {
    private int id;
    private String name;
    private String message;

    public Feedback(int id, String name, String message) {
        this.id = id;
        this.name = name;
        this.message = message;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getMessage() {
        return message;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    // Optional: toString() for debugging
    @Override
    public String toString() {
        return id + "," + name + "," + message;
    }

    // Optional: create a Feedback object from a string line
    public static Feedback fromString(String line) {
        String[] parts = line.split(",", 3);
        int id = Integer.parseInt(parts[0]);
        String name = parts[1];
        String message = parts[2];
        return new Feedback(id, name, message);
    }
}

