package com.tourism.tourismplatform.service;

import com.tourism.tourismplatform.util.TravelPackageBST;

import com.tourism.tourismplatform.model.TravelPackage;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TravelPackageService {

    private final TravelPackageBST packageBST = new TravelPackageBST();

    public List<TravelPackage> getAllPackagesSortedByCost() {
        return packageBST.getSortedPackagesByCost();
    }

    public void addPackage(TravelPackage travelPackage) {
        packageBST.insert(travelPackage);
    }
}


