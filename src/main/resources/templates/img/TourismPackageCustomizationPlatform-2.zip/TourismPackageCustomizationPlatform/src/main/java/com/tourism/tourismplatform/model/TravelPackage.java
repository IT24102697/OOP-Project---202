package com.tourism.tourismplatform.model;

public class TravelPackage {
    private String name;
    private String description;
    private int duration;
    private double cost;

    public TravelPackage(String name, String description, int duration, double cost) {
        this.name = name;
        this.description = description;
        this.duration = duration;
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getDuration() {
        return duration;
    }

    public double getCost() {
        return cost;
    }
}
