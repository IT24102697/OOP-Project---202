package com.tourismplatform;

public class TourismApp {
}
